#ifndef MENU_H
#define MENU_H

#include "../Lista/Lista.h"
#include <stdio.h>

int Menu(){
    int op;
    printf("\n#   MENU    #\n\n");
    printf("1. Emitir novo ingresso.\n");
    printf("2. Buscar ingresso por CPF.\n");
    printf("3. Numero de ingressos por data.\n");
    printf("0. Sair.\n\n");

    printf("Digite a opcao: ");
    scanf("%d", &op);

    return op;
}

void String_receber(char msg[], char string[], int tam){
    fflush(stdin);
    printf("%s", msg);
    fgets(string, tam, stdin);
    string[tam-1] = '\0';
    fflush(stdin);
}

Date Date_receber(){
    int dia, mes, ano;

    printf("\nDigite a data: \n");
    printf("Dia: ");
    scanf("%d", &dia);
    printf("Mes: ");
    scanf("%d", &mes);
    printf("Ano: ");
    scanf("%d", &ano);

    return Date_new(dia, mes, ano);
}

Ingresso* Ingresso_receber(){
    char CPF[13] = {};
    char nome[50] = {};

    String_receber("\nDigite seu nome: ", nome, 50);
    String_receber("Digite o CPF: ", CPF, 13);
    Ingresso_new(nome, CPF, Date_receber());
}

void Inserir_ingresso_lista(Lista *lista){
    Ingresso *novo = Ingresso_receber();

    if(!Lista_push(lista, novo)){
        printf("\nNao foi possivel emitir novo ingresso para a data: \n");
        Date_print(&novo->date_evento);
        printf("\n");
        free(novo);
    }
}

void Buscar_CPF(Lista *lista){
    char CPF[13] = {};
    String_receber("\nDigite o CPF: ", CPF, 13);
    Lista_print_CPF(lista, CPF);
}

void Num_ingressos_date(Lista *lista){
    if(!lista->inicio){
        printf("\nNenhum ingresso foi emitido.\n");
        return;
    }

    printf("\nA data e apos ela o numero de ingressos emitidos:\n\n");
    Lista_print_quant_ingres_date(lista);
}

void Opcoes(int op, Lista *lista){
    if(op == 1){
        Inserir_ingresso_lista(lista);
    }else if(op == 2){
        Buscar_CPF(lista);
    }else if(op == 3){
        Num_ingressos_date(lista);
    }else if(op != 0){
        printf("\nERRO.\n");
    }
}

#endif